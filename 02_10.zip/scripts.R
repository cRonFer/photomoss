wd.path <- ''
setwd(wd.path)

## chart

# We create the chart object (a list of polygons) with the chart2 function.
# To do this we click over the color cells chart in the image.
# Important note: follow the order as indicated in the figure below.
pic.format <-'tif'
pic.path = "./vis"
interactive = T
xriteclassic.chart = T
samp.width = 0.01

chart <- chart2(wd.path) 
# ROIS: Creates a readable polygon files from the ImageJ .roi files.
# Then we crop the pixels that fell inside the polygons and obtain a list polygon dataframe (obs.areas object)

roi_paths <- list.files(path = "./rois", pattern=".roi$", full.names = T, recursive = T)
obs.areas <- roi2polygon(roi.folder = "./rois", pic.folder = "./vis")
obs.areas <- obs_areas
##calcs

# The basic result of this function is a dataframe with the areas in number of pixels of background and moss area for each sample.
# If argument descrip = T the descriptive statistics of the different areas. que?
# The resulting data.frame is saved in a new folder in your working directory.
ccspectral.df(tif.path,
              chart, # object chart obtained wuith the function chart2
              obs.areas, # Polygon files obtained with roi2polygon.2 function
              pdf = F,
              calculate.thresh = T,
              descrip = T,
              manual.mask.test = F,
              index. = c("NDVI", "SR"),
              threshold.method = c("Huang"),
              threshold.vector = NULL,
              descriptors. = c("median", "mean", "sd", "min", "max", "diff.range")
)

area=all
photo=all
